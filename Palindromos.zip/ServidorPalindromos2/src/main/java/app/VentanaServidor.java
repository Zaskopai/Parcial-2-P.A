/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app;


import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;

public class VentanaServidor extends JFrame {

    private JTextArea areaRegistro;
    private JButton btnIniciar;
    private JButton btnDetener;

    // Objeto de la clase logica
    private ServidorPalindromos2 servidor;

    public VentanaServidor() {

        setTitle("Servidor de Palindromos");
        setSize(520, 430);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Crear objeto del servidor
        servidor = new ServidorPalindromos2(
            mensaje -> mostrarMensaje(mensaje)
        );

        // Panel de informacion
        JPanel panelSuperior = new JPanel();

        panelSuperior.setLayout(
            new BoxLayout(panelSuperior, BoxLayout.Y_AXIS)
        );

        panelSuperior.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 10, 15)
        );

        JLabel titulo = new JLabel("SERVIDOR TCP");

        titulo.setFont(
            new Font("Arial", Font.BOLD, 18)
        );

        panelSuperior.add(titulo);
        panelSuperior.add(Box.createVerticalStrut(10));

        panelSuperior.add(
            new JLabel("Localhost: 127.0.0.1")
        );

        panelSuperior.add(
            new JLabel("Puerto: 5000")
        );

        add(panelSuperior, BorderLayout.NORTH);

        // Area de registro
        areaRegistro = new JTextArea();

        areaRegistro.setEditable(false);

        areaRegistro.setFont(
            new Font("Monospaced", Font.PLAIN, 12)
        );

        add(
            new JScrollPane(areaRegistro),
            BorderLayout.CENTER
        );

        // Panel de botones
        JPanel panelBotones = new JPanel();

        btnIniciar = new JButton("Iniciar servidor");
        btnDetener = new JButton("Detener servidor");

        btnDetener.setEnabled(false);

        panelBotones.add(btnIniciar);
        panelBotones.add(btnDetener);

        add(panelBotones, BorderLayout.SOUTH);

        // Mostrar las IP reales del equipo
        mostrarMensaje("Localhost: 127.0.0.1");

        mostrarMensaje("IPv4 del equipo:");

        mostrarMensaje(
            ServidorPalindromos2.obtenerIPs()
        );

        // Eventos de los botones
        btnIniciar.addActionListener(
            e -> iniciar()
        );

        btnDetener.addActionListener(
            e -> detener()
        );

        // Cerrar el servidor al salir
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                servidor.detener();
            }
        });
    }

    // Iniciar servidor TCP
    private void iniciar() {

        try {

            servidor.iniciar(5000);

            btnIniciar.setEnabled(false);
            btnDetener.setEnabled(true);

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                this,
                "No se pudo iniciar el servidor:\n"
                + e.getMessage()
            );
        }
    }

    // Detener servidor
    private void detener() {

        servidor.detener();

        btnIniciar.setEnabled(true);
        btnDetener.setEnabled(false);
    }

    // Mostrar mensajes en la ventana
    private void mostrarMensaje(String mensaje) {

        SwingUtilities.invokeLater(() -> {

            areaRegistro.append(mensaje + "\n");

            areaRegistro.setCaretPosition(
                areaRegistro.getDocument().getLength()
            );
        });
    }

    // Ejecutar interfaz
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new VentanaServidor().setVisible(true);

        });
    }
}
