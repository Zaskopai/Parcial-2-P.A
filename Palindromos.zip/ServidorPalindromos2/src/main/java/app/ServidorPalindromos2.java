

package app;


import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class ServidorPalindromos2 {

    private ServerSocket servidor;
    private ExecutorService clientes;
    private Thread hiloServidor;

    private final Consumer<String> mostrarMensaje;

    public ServidorPalindromos2(Consumer<String> mostrarMensaje) {
        this.mostrarMensaje = mostrarMensaje;
    }

    // Iniciar el servidor
    public synchronized void iniciar(int puerto)
            throws IOException {

        if (servidor != null) {
            throw new IllegalStateException("El servidor ya esta iniciado.");
        }

        servidor = new ServerSocket(puerto);
        clientes = Executors.newCachedThreadPool();

        ServerSocket socketActual = servidor;
        ExecutorService grupoActual = clientes;

        mostrarMensaje.accept("Servidor iniciado en puerto " + puerto);

        hiloServidor = new Thread(() -> {

            mostrarMensaje.accept("Esperando clientes...");

            try {
                while (!socketActual.isClosed()) {

                    Socket cliente = socketActual.accept();

                    mostrarMensaje.accept("Cliente conectado: "+ cliente.getInetAddress().getHostAddress());

                    grupoActual.execute(() -> atenderCliente(cliente));
                }

            } catch (IOException e) {

                if (!socketActual.isClosed()) {
                    mostrarMensaje.accept("Error: " + e.getMessage());
                }

            } catch (RejectedExecutionException e) {
                // El servidor se estaba deteniendo.

            } finally {
                detener();
            }

        });

        hiloServidor.start();
    }

    // Atender solicitud
    private void atenderCliente(Socket cliente) {

        try (
            Socket conexion = cliente;

            BufferedReader entrada = new BufferedReader(
                new InputStreamReader(conexion.getInputStream(),StandardCharsets.UTF_8));

            PrintWriter salida = new PrintWriter(new OutputStreamWriter(conexion.getOutputStream(),StandardCharsets.UTF_8), true)) 
        {

            conexion.setSoTimeout(10000);

            String palabra = entrada.readLine();

            if (palabra == null) {
                return;
            }

            if (palabra.length() > 500) {
                salida.println("ERROR: Texto demasiado largo.");
                return;
            }

            mostrarMensaje.accept("Texto recibido: " + palabra);

            boolean resultado = esPalindromo(palabra);

            String respuesta = resultado? "SI es un palindromo": "NO es un palindromo";
            salida.println(respuesta);

            mostrarMensaje.accept("Respuesta: " + respuesta);

        } catch (IOException e) {
            mostrarMensaje.accept("Error con cliente: " + e.getMessage());
        }
    }

    // Comprobar palindromo
    public static boolean esPalindromo(String texto) {

        String normalizado = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");

        normalizado = normalizado.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");

        if (normalizado.isEmpty()) {
            return false;
        }

        String invertida = new StringBuilder(normalizado).reverse().toString();
        return normalizado.equals(invertida);
    }

    // Obtener direcciones IPv4 del equipo

public static String obtenerIPs() {
    try {
        InetAddress ip = InetAddress.getLocalHost();
        return ip.getHostAddress();

    } catch (UnknownHostException e) {
        return "No se pudo obtener la IP";
    }
}


    // Detener el servidor
    public synchronized void detener() {

        if (servidor == null) {
            return;
        }

        try {
            servidor.close();
        } catch (IOException e) {
            mostrarMensaje.accept(
                "Error al cerrar: " + e.getMessage()
            );
        }

        servidor = null;

        if (clientes != null) {
            clientes.shutdownNow();
            clientes = null;
        }

        mostrarMensaje.accept("Servidor detenido.");
    }

    public synchronized boolean estaActivo() {
        return servidor != null && !servidor.isClosed();
    }
}
