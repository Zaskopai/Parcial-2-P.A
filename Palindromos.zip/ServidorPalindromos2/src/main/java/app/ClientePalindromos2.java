
package app;


import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class ClientePalindromos2 {

    private final String host;
    private final int puerto;

    // Constructor
    public ClientePalindromos2(String host, int puerto) {
        this.host = host;
        this.puerto = puerto;
    }

    // Enviar palabra y recibir respuesta
    public String verificar(String palabra)
            throws IOException {

        if (palabra == null || palabra.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "La palabra no puede estar vacia."
            );
        }

        if (palabra.length() > 500
                || palabra.contains("\n")
                || palabra.contains("\r")) {

            throw new IllegalArgumentException(
                "Texto invalido o demasiado largo."
            );
        }

        try (Socket socket = new Socket()) {

            // Conectarse con el servidor
            socket.connect(
                new InetSocketAddress(host, puerto),
                3000
            );

            socket.setSoTimeout(5000);

            try (
                PrintWriter salida = new PrintWriter(
                    new OutputStreamWriter(
                        socket.getOutputStream(),
                        StandardCharsets.UTF_8
                    ), true
                );

                BufferedReader entrada = new BufferedReader(
                    new InputStreamReader(
                        socket.getInputStream(),
                        StandardCharsets.UTF_8
                    )
                )
            ) {

                // Enviar al servidor
                salida.println(palabra);

                if (salida.checkError()) {
                    throw new IOException(
                        "No fue posible enviar el texto."
                    );
                }

                // Recibir la respuesta
                String respuesta = entrada.readLine();

                if (respuesta == null) {
                    throw new IOException(
                        "El servidor no respondio."
                    );
                }

                return respuesta;
            }
        }
    }
}
