
package app;

import javax.swing.*;
import java.awt.*;

public class VentanaCliente extends JFrame {



    private JTextField campoIP;
    private JTextField campoPalabra;
    private JLabel resultado;
    private JButton btnVerificar;

    public VentanaCliente() {

        setTitle("Cliente de Palindromos");
        setSize(440, 310);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Panel principal
        JPanel panel = new JPanel(
            new GridLayout(5, 1, 5, 5)
        );

        panel.setBorder(
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        );

        JLabel titulo = new JLabel(
            "CLIENTE TCP - PALINDROMOS"
        );

        titulo.setFont(
            new Font("Arial", Font.BOLD, 17)
        );

        panel.add(titulo);

        // Campo para IP del servidor
        JPanel panelIP = new JPanel(
            new BorderLayout(5, 0)
        );

        panelIP.add(
            new JLabel("IP del servidor:"),
            BorderLayout.WEST
        );

        campoIP = new JTextField("127.0.0.1");

        panelIP.add(
            campoIP,
            BorderLayout.CENTER
        );

        panel.add(panelIP);

        // Campo para palabra o frase
        panel.add(
            new JLabel("Ingrese palabra o frase:")
        );

        campoPalabra = new JTextField();

        panel.add(campoPalabra);

        // Boton
        btnVerificar = new JButton(
            "Verificar palindromo"
        );

        panel.add(btnVerificar);

        add(panel, BorderLayout.CENTER);

        // Etiqueta de resultado
        resultado = new JLabel(
            "Esperando consulta...",
            SwingConstants.CENTER
        );

        resultado.setBorder(
            BorderFactory.createEmptyBorder(8, 8, 15, 8)
        );

        add(resultado, BorderLayout.SOUTH);

        // Eventos
        btnVerificar.addActionListener(
            e -> verificarPalabra()
        );

        campoPalabra.addActionListener(
            e -> verificarPalabra()
        );
    }

    // Enviar la palabra utilizando ClientePalindromos2
    private void verificarPalabra() {

        String host = campoIP.getText().trim();
        String palabra = campoPalabra.getText().trim();

        // Validar datos
        if (host.isEmpty() || palabra.isEmpty()) {

            JOptionPane.showMessageDialog(
                this,
                "Ingrese la IP y la palabra."
            );

            return;
        }

        btnVerificar.setEnabled(false);

        resultado.setForeground(Color.BLACK);
        resultado.setText("Consultando servidor...");

        // Ejecutar comunicacion en segundo plano
        SwingWorker<String, Void> tarea =
            new SwingWorker<String, Void>() {

            @Override
            protected String doInBackground()
                    throws Exception {

                // Crear objeto de la clase logica
                ClientePalindromos2 cliente =
                    new ClientePalindromos2(host, 5000);

                // Enviar palabra y recibir respuesta
                return cliente.verificar(palabra);
            }

            @Override
            protected void done() {

                btnVerificar.setEnabled(true);

                try {

                    String respuesta = get();

                    resultado.setText(respuesta);

                    if (respuesta.startsWith("SI")) {

                        resultado.setForeground(
                            new Color(0, 130, 0)
                        );

                    } else {

                        resultado.setForeground(Color.RED);
                    }

                } catch (Exception e) {

                    resultado.setForeground(Color.RED);

                    Throwable causa = e.getCause() != null
                        ? e.getCause() : e;

                    resultado.setText(
                        "Error: " + causa.getMessage()
                    );
                }
            }
        };

        tarea.execute();
    }

    // Ejecutar interfaz
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new VentanaCliente().setVisible(true);

        });
    }
}


